#include <iostream>
using namespace std;

int main()
{
    int i=1;
 do {
  cout << "C++" << endl;
  i++;
 } while (i<=10);
    return 0;
}
