#include <iostream>
using namespace std;
 
int main()
{
    int pilihan = 1;
    do{
        cout<<"Masukan nomer : ";cin>>pilihan;
    }while(pilihan<=10);
 
    return 0;
}
