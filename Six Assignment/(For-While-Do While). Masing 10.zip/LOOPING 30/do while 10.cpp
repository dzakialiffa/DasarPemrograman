#include <iostream>
using namespace std;

int main()
{
    int no=1, pilihan;
    cout << "Mau cetak berapa ? ";
    cin >> pilihan;
 do {
  cout << no << "). Aku Suka Koding" << endl;
  no++;
 } while (no <= pilihan);
    return 0;
}
