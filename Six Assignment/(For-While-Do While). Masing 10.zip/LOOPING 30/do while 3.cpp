include <iostream>
 
using namespace std;
 
int main()
{
  int i = 10;
  do {
    cout << i * 3 << " ";
    i++;
  }
  while (i <= 5);
 
  return 0;
}
