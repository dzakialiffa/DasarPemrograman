#include <stdio.h>
 
int main(void)
{
  int i = 1;
  while (i <= 5){s
    printf("Hello World \n");
    i++;
  }
  return 0;
}
