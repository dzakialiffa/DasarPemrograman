#include <iostream>
 
using namespace std;
 
int main()
{
  int i = 1;
  do {
    cout << "Hello World" << endl;
    i++;
  }
  while (i <= 5);
 
  return 0;
}
