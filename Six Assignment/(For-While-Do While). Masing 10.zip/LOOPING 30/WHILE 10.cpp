#include<iostream>
using namespace std;

int main(){

     int x = 0;
    
     while(x < 10){
      cout<<"x : "<<x<<endl;

      cout<<"Belajar perulangan while C++ \n";


      x += 3;  // x = x + 3, kenaikan nilai x sejumlah 3
  }
}
