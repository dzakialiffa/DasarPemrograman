#include <iostream>
using namespace std;
int main()
{
    a:
    int pilihan = 0;
    string data;

    cout << "n1. Masukan nama";
    cout << "n2. Masukan NIM";
    cout << "n3. Masukan kelas";
    cout << "n4. Exit";
    cout << "nPilihanmu >> ";
    cin >> pilihan;
    if(pilihan != 4){ //jika pilihan = 4 maka eksekusi pernyataan else
        while(pilihan < 4 && pilihan > 0){
            cout << "Masukan data sesuai dengan yang anda pilih : ";
            cin >> data;
            cout << "=======================" << endl;
            switch(pilihan){
            case 1:
                cout << "Namamu > " << data << endl;
                break;
            case 2:
                cout << "NIMmu > " << data << endl;
                break;
            case 3:
                cout << "Kelasmu > " << data << endl;
                break;
            }
            cout << "=======================" << endl;
            goto a;
        }
    }
    else{
        cout << "Anda sudah keluar dari aplikasi !" << endl;
    }
    return 0;
}
