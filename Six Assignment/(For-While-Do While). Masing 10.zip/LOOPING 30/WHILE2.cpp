#include <iostream> using namespace std; int main ()
  {
  int x=0, y=0; while(x<3) {
  y=y+3; x++;
  }
  cout<<y; return 0;
  }
