#include <stdio.h>
 
int main(void)
{
  int i;
  for (i = 1; i <= 10; i++) {
    printf("%i ",i*3);
  }
  printf("\n");
  return 0;
}
