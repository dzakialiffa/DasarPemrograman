#include <iostream>
using namespace std;

int main()
{
    int i = 1; //buat variebl i untuk while dan do-while

    while(i <= 5){
        cout << "Hello World, hasil dari : while" << endl;
        i++;
    }

    do{
        cout << "Hello World, hasil dari : do-while" << endl;
        i++;
    }while(i <= 5);
    cout << endl;

    return 0;
}
