#include <stdio.h>
 
int main(void)
{
  int i;
  for (i = 1; i <= 5; i++) {
    printf("Hello World %i \n",i);
  }
  return 0;
}
