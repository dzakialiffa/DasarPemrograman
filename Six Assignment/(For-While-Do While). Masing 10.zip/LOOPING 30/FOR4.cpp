#include<iostream>
using namespace std;
int main(){
     int i;
        cout<<"masukan i : ";cin>>i;
   // cek bilangan, jika ganjil kurangi 1
     if(i % 2 !=0 )
         i--;
  // menampilkan deret bilangan genap dari besar hingga 0
     for( ; i >= 0; i -= 2 ){
           cout<<i<<" ";
      }
}
