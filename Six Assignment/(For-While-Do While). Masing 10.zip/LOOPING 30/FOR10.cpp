#include <stdio.h>
 
int main(void)
{
  int i;
  for (i = 3; i <= 30; i = i + 3) {
    printf("%i ",i);
  }
  printf("\n");
  return 0;
}
