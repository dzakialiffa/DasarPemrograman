#include <stdio.h>
 
int main(void)
{
  int i = 1;
  while (i <= 5){
    printf("Hello World %i \n",i);
    i++;
  }
  return 0;
}
