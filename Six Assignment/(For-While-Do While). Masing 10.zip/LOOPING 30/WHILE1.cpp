#include <iostream> using namespace std; int main ()
  {
  int x=0, y=0; do {
  y=y+3; x++;
  }
  while(x<3); cout<<y; return 0;
  }
