#include <stdio.h>
 
int main(void)
{
  int i;
  for (i = 1; i <= 5; i++) {
    printf("Hello World \n");
  }
  return 0;
}
